using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnManager : MonoBehaviour
{
    // Start is called before the first frame update
    [Tooltip("minum height the object can reach before respawning")]
    public Vector3 minimumHeight = new Vector3(0, -100, 0);
    [Tooltip ("if this is checked the player will always respawn were he started")]
    public bool useAutomaticRespawnPoint = false;
    [Tooltip ("only used if previous box is not checked")]
    public Vector3 respawnPoint;

    private CharacterController controller = null;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        if (useAutomaticRespawnPoint)
        {
            respawnPoint = transform.position;
        }
        transform.position = respawnPoint;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.y <= minimumHeight.y)
        {
            if (controller != null)
                controller.enabled = false;
            transform.position = respawnPoint;
            if (controller != null)
                controller.enabled = true;
        }
    }
}
