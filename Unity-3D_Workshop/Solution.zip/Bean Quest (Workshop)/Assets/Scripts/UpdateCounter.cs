using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpdateCounter : MonoBehaviour
{
    public Text counterText;
    public PlayerController playerInfo;

    int beanCount = 0;

    // Start is called before the first frame update
    void Start()
    {
        beanCount = playerInfo.beansCollected;
        counterText.text = "x" + beanCount.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (playerInfo.beansCollected > beanCount)
        {
            beanCount++;
            counterText.text = "x" + beanCount.ToString();
        }
    }
}
