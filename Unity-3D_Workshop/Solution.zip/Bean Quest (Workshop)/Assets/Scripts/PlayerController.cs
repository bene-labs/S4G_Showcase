using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    [Tooltip("units per second the player moves by default")]
    public float baseMoveSpeed = 4.0f;
    [Tooltip("units per second the player moves when sprinting")]
    public float sprintMoveSpeed = 7.5f;
    public float jumpHeight = 3.0f;
    [Tooltip("number of jumps possible in between touching the ground")]
    public int maxJumps = 2;

    float moveSpeed;

    private int jumpsLeft;

    CharacterController controller;

    [Header("Phyics")]
    public float gravity = 9.81f;
    public Transform groundCheck;
    public float maxGroundDistance = 0.4f;
    public LayerMask groundMask;
    public Vector3 externalMovement;
    Vector3 velocity;
    bool isGrounded;

    [Header("Collectibles")]
    public int beansCollected = 0;
    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();

        moveSpeed = baseMoveSpeed;
        jumpsLeft = maxJumps;
    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        if (Input.GetKey("left shift"))
        {
            moveSpeed = sprintMoveSpeed;
        } else
        {
            moveSpeed = baseMoveSpeed;
        }

        Vector3 movement = transform.right * x + transform.forward * z;
        controller.Move(movement * moveSpeed * Time.deltaTime);
        isGrounded = Physics.CheckSphere(groundCheck.position, maxGroundDistance, groundMask);

        velocity.y += gravity * Time.deltaTime;

        if (Input.GetButtonDown("Jump") && jumpsLeft > 0)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
            jumpsLeft--;
        }

        if (isGrounded)
        {
            if (velocity.y < 0)
            {
                jumpsLeft = maxJumps;
                velocity.y = -2f;
            }
        }
        controller.Move(velocity * Time.deltaTime + externalMovement);
    }
}
