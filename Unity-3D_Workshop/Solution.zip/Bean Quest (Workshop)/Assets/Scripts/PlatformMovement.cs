using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformMovement : MonoBehaviour
{
    [Tooltip("Intial position of the platform")]
    public Transform pointA;
    [Tooltip("Intial goal of the platform")]
    public Transform pointB;
    [Tooltip("Speed (in u/sec) that tha plaform has to constanly move between the two points")]
    public float moveSpeed = 3.0f;

    private Vector3 movement;
    private Vector3 goalPosition;
    // Start is called before the first frame update
    void Start()
    {
        transform.position = pointA.position;
        goalPosition = pointB.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position == goalPosition)
        {
            goalPosition = (goalPosition == pointA.position ? pointB.position : pointA.position);
        }
        movement = Vector3.MoveTowards(transform.position, goalPosition, moveSpeed * Time.deltaTime) - transform.position;
        transform.position += movement; // = Vector3.MoveTowards(transform.position, goalPositon, moveSpeed * Time.deltaTime);
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "Player")
        {
            print("Player touched!");
            other.gameObject.GetComponent<PlayerController>().externalMovement = movement;

        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            print("Player left!");
            other.gameObject.GetComponent<PlayerController>().externalMovement = new Vector3(0, 0, 0);
        }
    }
}
